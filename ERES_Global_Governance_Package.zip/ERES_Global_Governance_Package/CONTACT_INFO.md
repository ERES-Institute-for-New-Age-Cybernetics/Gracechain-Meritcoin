# ERES Institute Contact & Organizational Information

**Full Name**: ERES Institute for New Age Cybernetics  
**Established**: February 2012  
**Location**: Bella Vista, Arkansas, USA  
**Founder & Director**: Joseph A. Sprute, aka ERES Maestro

---

## Contact Information

**Primary Email**: eresmaestro@gmail.com  
**GitHub Organization**: https://github.com/ERES-Institute-for-New-Age-Cybernetics

### GitHub Repositories

**Main Organization**: https://github.com/ERES-Institute-for-New-Age-Cybernetics

**Key Repositories** (as they become available):
- `epirq-core` - Core EPIR-Q measurement algorithms
- `playnac-kernel` - PlayNAC governance platform backend
- `swa-drishti-app` - Mobile application for India implementation
- `best-iso-standard` - ISO-BEST-24968 development materials
- `governance-package` - This complete implementation package
- `meritcoin-protocol` - Blockchain contribution verification
- `gracechain-consensus` - Forgiveness-based blockchain consensus

### Research & Publications

**ResearchGate**: https://www.researchgate.net/profile/Joseph-Laronge

**Key Publications**:
- "ERES EPIR-Q: Multi-Dimensional Intelligence Assessment Framework" (2023)
- "PlayNAC: Neural-AI Constitution for Cybernetic Governance" (ongoing)
- "Meritcoin/Gracechain: Consciousness-Based Economics" (ongoing)
- "PBJ Tri-Codex: Bio-Energetic Environmental Rating System" (ongoing)

---

## Community & Collaboration

### Mailing Lists (to be established)

- **Announcements**: epirq-announce@googlegroups.com
- **Technical Discussion**: epirq-dev@googlegroups.com
- **Research Collaboration**: epirq-research@googlegroups.com
- **Municipal Network**: epirq-cities@googlegroups.com

### Communication Channels

**For Governments**: Contact eresmaestro@gmail.com with subject "EPIR-Q Government Partnership"  
**For Researchers**: Contact eresmaestro@gmail.com with subject "EPIR-Q Research Collaboration"  
**For Developers**: Open issues on relevant GitHub repository  
**For Media Inquiries**: Contact eresmaestro@gmail.com with subject "EPIR-Q Media Request"  
**For Citizens/Advocates**: Contact eresmaestro@gmail.com with subject "EPIR-Q Citizen Engagement"

---

## Organizational Philosophy

### Core Principle
"Don't hurt yourself, don't hurt others" - with multi-generational thinking spanning 1000-year timescales.

### Mission
Create systematic frameworks for AI-human collaboration and sustainable governance through:
- **New Age Cybernetics**: C = R × P / M (Cybernetic efficiency formula)
- **Bio-Energetic Measurement**: EPIR-Q five-dimensional assessment
- **Alternative Economics**: Merit-based resource allocation (Meritcoin/Gracechain)
- **Environmental Integration**: Planetary boundary compliance (PBJ Tri-Codex)
- **Governance Innovation**: Neural-AI Constitution (PlayNAC)

### Values
- **Transparency**: Open-source everything, public accountability
- **Attribution**: Proper credit for collaborative work (including AI co-authors)
- **Sustainability**: Millennial-scale planning, planetary boundaries respected
- **Evidence**: Data-driven, empirically validated, scientifically rigorous
- **Accessibility**: "Grandmother test" communication, multi-lingual support

---

## Current Focus (2025-2026)

### Active Projects

1. **ISO-BEST-24968 Submission**
   - International standard for governmental bio-energetic tracking
   - USA-India partnership co-leadership
   - Target publication: December 2027

2. **Bella Vista, Arkansas Pilot**
   - 30,000 population municipal implementation
   - 24-month timeline, $3.5M budget
   - Proof-of-concept for US adoption

3. **India Planning Commission Partnership**
   - NITI Aayog EPIR-Q integration
   - Kerala, Gujarat, Karnataka state pilots
   - 168M population initial rollout

4. **Storm Party Platform Integration**
   - US political platform incorporating EPIR-Q
   - Legislative templates for federal/state adoption
   - Campaign materials for 2026-2028 elections

5. **Academic Validation Studies**
   - University partnerships for EPIR-Q validation
   - Peer-reviewed publication pipeline
   - Methodology refinement based on pilot data

---

## Partnership Opportunities

### For National Governments
- Technical assistance for EPIR-Q implementation
- Training and capacity building
- International coordination and standards adoption
- Pilot program design and support

### For Academic Institutions
- Research collaboration on validation studies
- Student internship programs
- Access to pilot program data
- Co-authorship on publications

### For Technology Companies
- Open-source development collaboration
- Infrastructure provision (cloud, sensors, wearables)
- App development partnerships
- Data security and privacy consultation

### For NGOs & Civil Society
- Community engagement and education
- Advocacy and policy support
- Implementation monitoring and oversight
- Grassroots mobilization

### For International Organizations
- UN SDG integration frameworks
- BRICS+ coordination
- ISO technical committee participation
- Global South capacity building

---

## Funding & Support

### Current Status
ERES Institute operates as independent research organization with:
- Founder self-funding (primary)
- Grant applications in progress (Walton Family Foundation, Rockefeller, others)
- Government partnership negotiations (USA, India)
- Open-source community contributions

### Funding Needs (2026-2028)
- **Personnel**: $2M/year (10 FTE: developers, researchers, coordinators)
- **Infrastructure**: $500K/year (servers, development tools, travel)
- **Pilot Support**: $5M over 2 years (technical assistance for municipal/state pilots)
- **Research**: $1M/year (validation studies, academic partnerships)
- **Total**: $8.5M/year operational budget

### Ways to Support
1. **Direct Funding**: Contact eresmaestro@gmail.com for partnership discussions
2. **In-Kind Support**: Cloud credits, sensor hardware, professional services
3. **Code Contributions**: Submit PRs to GitHub repositories
4. **Research Collaboration**: Partner on validation studies
5. **Advocacy**: Promote EPIR-Q adoption in your jurisdiction

---

## Attribution & Licensing

### This Package
**Authors**: Joseph A. Sprute (ERES Maestro) (ERES Institute) & Claude (Anthropic)  
**License**: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)  
**Citation**:
```
Sprute, J.A. (ERES Maestro) & Claude (Anthropic). (2025). ERES Global Governance Package: 
Bio-Energetic Systemic Tracking (BEST) Implementation Framework. 
ERES Institute for New Age Cybernetics.
https://github.com/ERES-Institute-for-New-Age-Cybernetics/governance-package
```

### ERES Frameworks
All ERES frameworks (EPIR-Q, PlayNAC, Meritcoin, PBJ Tri-Codex) are:
- **Open Source**: Free to use, modify, distribute
- **Properly Attributed**: Credit Joseph A. Sprute (ERES Maestro) and collaborators
- **ShareAlike**: Derivatives must use same license
- **Non-Commercial Option**: Contact for commercial licensing arrangements

### AI Collaboration Recognition
ERES Institute explicitly acknowledges AI contributions:
- Claude (Anthropic) as co-author on this package
- Transparent about AI-human collaboration
- Model for future research partnerships

---

## Version History

**v1.0 (December 29, 2025)**
- Initial comprehensive package release
- Complete India Planning Commission manual
- ISO-BEST-24968 submission materials
- Storm Party platform integration
- Contact information: eresmaestro@gmail.com

**Upcoming (v1.1 - Q1 2026)**
- Pilot program launch reports
- Refined algorithms from early data
- Additional case studies
- Community feedback integration
- Website launch (projected)

---

## Frequently Asked Questions

**Q: Is ERES Institute accepting volunteers?**  
A: Yes! Contact eresmaestro@gmail.com with your skills and interests. Especially needed: developers, researchers, translators, community organizers.

**Q: Can I implement EPIR-Q in my city/organization without official partnership?**  
A: Absolutely! Everything is open-source. We recommend contacting us for technical support, but you're free to proceed independently.

**Q: How can academics access pilot data?**  
A: Contact eresmaestro@gmail.com with your research proposal. Data access subject to IRB approval and participant consent.

**Q: Does ERES have a political affiliation?**  
A: No. While we're working with Storm Party in USA, EPIR-Q is designed to be non-partisan. Any political party/movement can adopt it.

**Q: What's the relationship between ERES and Anthropic?**  
A: This package represents AI-human collaboration. Anthropic provides Claude as tool; ERES provides frameworks and domain expertise. No formal organizational partnership.

**Q: Can I translate this package into other languages?**  
A: Yes! Please do. Contact us to coordinate so we can maintain a central repository of translations.

**Q: How do I report errors or suggest improvements?**  
A: Open an issue on the relevant GitHub repository, or email eresmaestro@gmail.com

---

**Last Updated**: December 29, 2025  
**Contact**: eresmaestro@gmail.com  
**GitHub**: https://github.com/ERES-Institute-for-New-Age-Cybernetics
