# BERA-PY Quick Start Guide
## Get Running in 5 Minutes

---

## Step 1: Extract the Package

```bash
tar -xzf bera-py-v0.1.0.tar.gz
cd bera-py
```

---

## Step 2: Install Dependencies

### Option A: Using pip (Recommended)

```bash
# Create virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install the package in development mode
pip install -e .
```

### Option B: Install from requirements.txt

```bash
pip install -r requirements.txt
```

---

## Step 3: Verify Installation

```bash
python -c "import bera; print(bera.hello())"
```

**Expected output**:
```
BERA-PY v0.1.0 - Bio-Energetic Resonance Architecture
```

---

## Step 4: Run Examples

```bash
python examples/basic_usage.py
```

This will demonstrate:
- Creating synthetic bio-energetic states
- Calculating pairwise resonance
- Generating BEST timestamps
- Computing contribution quality scores
- Analyzing group resonance fields
- Counterfactual impact analysis
- Temporal tracking

---

## Step 5: Run Tests

```bash
# Install test dependencies
pip install pytest pytest-cov

# Run tests
pytest tests/test_core.py -v

# Run with coverage report
pytest tests/test_core.py --cov=bera --cov-report=html
```

---

## Basic Usage Example

```python
from bera.core import StateVector, AcousticVector, ChemicalVector
from bera.core import ResonanceCalculator, BESTTimestamp, CQSCalculator
from bera.metrics import GroupFieldCalculator

# Create a bio-energetic state
state = StateVector(
    individual_id="alice",
    chemical=ChemicalVector(
        cortisol=15.0,      # Stress marker (nmol/L)
        oxytocin=40.0,      # Bonding marker (pg/mL)
        cytokines={
            "IL-6": 2.0,
            "TNF-α": 1.5,
            "IL-10": 3.0,
            "IL-1β": 1.0
        }
    )
)

# Generate immutable timestamp
timestamp = BESTTimestamp.generate(state)
print(f"BEST: {timestamp}")

# Calculate resonance with another person
state_bob = StateVector(individual_id="bob", chemical=...)
calc = ResonanceCalculator()
resonance = calc.pairwise(state, state_bob)
print(f"Resonance: {resonance.overall:.3f}")

# Compute contribution quality score
group_states = [state, state_bob, ...]
cqs_calc = CQSCalculator()
cqs = cqs_calc.compute(state, group_states)
print(f"CQS: {cqs.overall:.3f}")

# Analyze group field
grf_calc = GroupFieldCalculator()
grf = grf_calc.compute(group_states)
print(f"GRF: {grf.grf_score:.3f}")
```

---

## What's Included

### ✅ Fully Implemented
- **Core Module**: State vectors, resonance, timestamps, CQS
- **Metrics Module**: Group resonance fields, conflict detection
- **Tests**: Comprehensive pytest suite
- **Examples**: Working demonstrations with synthetic data
- **Documentation**: README, package summary, this guide

### 🔲 Ready for Implementation (Stubs in Place)
- Sensors module (hardware drivers)
- Blockchain module (Gracechain/Meritcoin)
- API module (REST server)
- Integration module (ERES frameworks)
- Privacy module (anonymization, ZK proofs)
- Visualization module (dashboards)

---

## File Structure

```
bera-py/
├── bera/                   # Main package
│   ├── core/               # ✅ State vectors, resonance, BEST, CQS
│   ├── metrics/            # ✅ Group fields
│   ├── sensors/            # 🔲 Stub - ready for sensors
│   ├── blockchain/         # 🔲 Stub - ready for Gracechain
│   ├── integration/        # 🔲 Stub - ready for ERES
│   ├── privacy/            # 🔲 Stub - ready for security
│   ├── api/                # 🔲 Stub - ready for REST API
│   ├── visualization/      # 🔲 Stub - ready for dashboards
│   └── utils/              # 🔲 Stub - ready for utilities
├── tests/                  # ✅ Pytest suite
├── examples/               # ✅ Working examples
├── docs/                   # 🔲 Ready for Sphinx
├── README.md               # ✅ Comprehensive guide
├── PACKAGE_SUMMARY.md      # ✅ Implementation status
├── setup.py                # ✅ Installation config
├── pyproject.toml          # ✅ Modern packaging
└── requirements.txt        # ✅ Dependencies
```

---

## Next Steps

1. **Explore the Examples**:
   ```bash
   python examples/basic_usage.py
   ```

2. **Read the Documentation**:
   - `README.md` - Full user guide
   - `PACKAGE_SUMMARY.md` - Implementation roadmap
   - `docs/` - API reference (to be built with Sphinx)

3. **Run the Tests**:
   ```bash
   pytest tests/ -v
   ```

4. **Start Development**:
   - Pick a module to implement (sensors recommended first)
   - Follow the patterns in `bera/core/`
   - Add tests to `tests/`
   - Update examples

---

## Getting Help

- **Documentation**: See README.md and PACKAGE_SUMMARY.md
- **Examples**: Check examples/basic_usage.py
- **Tests**: Review tests/test_core.py for usage patterns
- **Issues**: Contact joseph@eres.institute

---

## System Requirements

- **Python**: 3.9 or higher
- **OS**: Linux, macOS, or Windows
- **RAM**: 4GB minimum (8GB recommended for large groups)
- **Storage**: 100MB for package + dependencies

### Optional Hardware (for full deployment)
- Microphone: Any USB mic (48kHz+ for full spectrum)
- ECG: Polar H10 or Empatica E4
- EEG: OpenBCI Cyton (8-channel minimum)
- Thermal camera: FLIR One Pro
- Lab equipment: Point-of-care cortisol/cytokine assays

---

## Troubleshooting

### Import Error
```bash
# Make sure you're in the right directory
cd bera-py
pip install -e .
```

### Missing Dependencies
```bash
# Install all dependencies
pip install -r requirements.txt
```

### Test Failures
```bash
# Check Python version
python --version  # Should be 3.9+

# Reinstall in clean environment
python -m venv fresh_venv
source fresh_venv/bin/activate
pip install -e .
pytest tests/
```

---

## Contributing

This is an open-source project under MIT license. Contributions welcome!

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

---

**Version**: 0.1.0  
**Author**: Joseph A. Sprute, ERES Institute  
**License**: MIT  
**Date**: December 2025
