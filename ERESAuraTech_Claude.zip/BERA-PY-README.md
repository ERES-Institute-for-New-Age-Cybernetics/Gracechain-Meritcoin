# BERA-PY: Bio-Energetic Resonance Architecture

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

A comprehensive Python library for measuring, analyzing, and leveraging bio-energetic resonance patterns in human physiological systems. Implements the ERES Institute's framework for acoustic-biometric signaling, neuroendocrine-immune coupling, and collective cognitive sentience.

## Overview

BERA-PY provides tools to:

- **Measure bio-energetic state vectors (BESV)** across acoustic, electromagnetic, chemical, and thermal modalities
- **Calculate resonance metrics** between individuals and groups
- **Generate immutable BEST timestamps** for contribution verification
- **Compute Contribution Quality Scores (CQS)** for merit-based economics
- **Implement Gracechain blockchain** with Proof-of-Resonance consensus
- **Integrate with ERES frameworks** (PBJ Tri-Codex, ERI, SMAS)
- **Visualize resonance fields** and collective dynamics

## Scientific Foundation

Based on research published in:
- "Acoustic Biometric Signaling as a Mechanism for Unconscious Physiological Synchronization" (Sprute, 2025)
- Psychoneuroimmunology (Ader & Cohen, 1975; Dantzer et al., 2008)
- Interpersonal physiological synchrony literature (Palumbo et al., 2017)

## Installation

```bash
pip install bera-py
```

### From source:

```bash
git clone https://github.com/eres-institute/bera-py.git
cd bera-py
pip install -e .
```

### Development installation:

```bash
pip install -e ".[dev]"
```

## Quick Start

```python
import bera
from bera.sensors import AcousticSensor, EMSensor
from bera.core import StateVector, ResonanceCalculator

# Initialize sensors
acoustic = AcousticSensor(sample_rate=48000)
em_sensor = EMSensor(ecg_enabled=True, eeg_enabled=True)

# Collect bio-energetic state
state = StateVector()
state.acoustic = acoustic.read()
state.electromagnetic = em_sensor.read()

# Calculate pairwise resonance
resonance_calc = ResonanceCalculator()
prc = resonance_calc.pairwise(state_person_a, state_person_b)

# Generate BEST timestamp
from bera.core import BESTTimestamp
timestamp = BESTTimestamp.generate(state)

# Calculate Contribution Quality Score
from bera.metrics import CQSCalculator
cqs_calc = CQSCalculator()
score = cqs_calc.compute(state, group_context)

print(f"Resonance: {prc:.3f}, CQS: {score:.3f}, BEST: {timestamp}")
```

## Architecture

### Core Components

- **`bera.core`**: Fundamental data structures (BESV, resonance, BEST, CQS)
- **`bera.sensors`**: Hardware abstraction layer for biometric devices
- **`bera.metrics`**: Resonance calculation, group fields, conflict detection
- **`bera.blockchain`**: Gracechain implementation with Meritcoin
- **`bera.integration`**: ERES framework connectors (PBJ, ERI, SMAS)
- **`bera.privacy`**: Anonymization, differential privacy, zero-knowledge proofs
- **`bera.api`**: REST API server and client
- **`bera.visualization`**: Plotting and dashboard tools

## Hardware Support

### Certified Devices

| Modality | Device | Notes |
|----------|--------|-------|
| Acoustic | RME Fireface UCX + Earthworks M30 | Professional audio interface |
| Acoustic | Smartphone microphone | Consumer-grade option |
| EM-Cardiac | Polar H10 | Medical-grade ECG |
| EM-Cardiac | Empatica E4 | PPG + EDA wearable |
| EM-Neural | OpenBCI Cyton | 8-channel EEG |
| Chemical | Point-of-care immunoassay | Cortisol/cytokines |
| Thermal | FLIR One Pro | Mobile thermal camera |

### Custom Sensor Integration

```python
from bera.sensors.base import BERASensor

class CustomSensor(BERASensor):
    modality = "electromagnetic"
    
    def calibrate(self, baseline_data):
        """Implement calibration logic"""
        pass
    
    def read(self):
        """Return current measurement"""
        return {"hr": 72, "hrv": 45.2}
    
    def verify(self):
        """Self-test"""
        return {"status": "operational"}
```

## API Server

Start the BERA API server:

```bash
bera-server --host 0.0.0.0 --port 8000 --workers 4
```

API documentation available at: `http://localhost:8000/docs`

### Example API Calls

```python
import requests

# Submit state
response = requests.post(
    "http://localhost:8000/api/v1/state",
    headers={"Authorization": "Bearer {token}"},
    json={"besv": state_dict}
)
best_timestamp = response.json()["BEST"]

# Query group resonance
response = requests.get(
    "http://localhost:8000/api/v1/resonance",
    params={"group_id": "pilot-group-1", "time": "2025-12-13T14:30:00Z"}
)
grf = response.json()["GRF"]
```

## Blockchain & Meritcoin

```python
from bera.blockchain import Gracechain, Meritcoin

# Initialize blockchain
chain = Gracechain(network="testnet")

# Record contribution
entry = {
    "individual_id": hashed_id,
    "BEST": timestamp,
    "CQS": score,
    "merit_accrued": 42.5
}
block = chain.add_entry(entry)

# Issue Meritcoin
meritcoin = Meritcoin(chain)
balance = meritcoin.issue(individual_id, merit_amount)
```

## Integration with ERES Frameworks

### PBJ Tri-Codex

```python
from bera.integration import PBJTriCodex

tricodex = PBJTriCodex()

# PERC: Personal bio-energetic record
tricodex.perc.add_state(individual_id, state_vector)

# BERC: Bio-energetic resonance context
tricodex.berc.add_resonance(individual_id, resonance_scores)

# JERC: Joint economic-resonance context
tricodex.jerc.add_group_field(group_id, grf_score)
```

### Emission Resonance Index (ERI)

```python
from bera.integration import ERICalculator

eri_calc = ERICalculator()

# Measure environmental impact
eri_score = eri_calc.compute(
    location="office-building-A",
    before_states=[state1, state2, ...],
    after_states=[state1_after, state2_after, ...]
)

# Negative ERI = degrading environment
# Positive ERI = enhancing environment
```

### SMAS Seven-Domain

```python
from bera.integration import SMASVerifier

smas = SMASVerifier()

domain_scores = smas.verify_all_domains(state_vector)
# Returns: {
#   'somatic': 0.78,
#   'mental': 0.65,
#   'affective': 0.82,
#   'social': 0.71,
#   'material': 0.55,
#   'aesthetic': 0.60,
#   'spiritual': 0.73
# }
```

## Visualization

```python
from bera.visualization import ResonancePlot, GroupFieldDashboard

# Plot pairwise resonance over time
plot = ResonancePlot()
plot.timeseries(individual_a, individual_b, time_range="1h")
plot.show()

# Launch interactive dashboard
dashboard = GroupFieldDashboard(group_id="pilot-group-1")
dashboard.run(port=8050)  # Access at http://localhost:8050
```

## Privacy & Security

```python
from bera.privacy import KAnonymizer, DifferentialPrivacy, ZeroKnowledgeProof

# K-anonymization of group data
anonymizer = KAnonymizer(k=5)
published_grf = anonymizer.anonymize(group_field_data)

# Differential privacy for individual states
dp = DifferentialPrivacy(epsilon=0.1)
noisy_state = dp.add_noise(state_vector)

# Zero-knowledge CQS proof
zkp = ZeroKnowledgeProof()
proof = zkp.prove_cqs_threshold(state_vector, threshold=0.7)
is_valid = zkp.verify(proof)  # Returns True/False without revealing state
```

## Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=bera --cov-report=html

# Run specific test suite
pytest tests/test_metrics/
```

## Documentation

Full documentation available at: https://bera-py.readthedocs.io

Build docs locally:

```bash
cd docs
make html
```

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Development Setup

```bash
git clone https://github.com/eres-institute/bera-py.git
cd bera-py
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -e ".[dev]"
pre-commit install
```

### Code Style

- Black for formatting
- isort for import sorting
- flake8 for linting
- mypy for type checking

```bash
make format  # Auto-format code
make lint    # Check code quality
make type    # Type checking
```

## Roadmap

- [x] Core BESV implementation
- [x] Resonance metrics
- [x] BEST timestamping
- [x] Gracechain blockchain
- [ ] Real-time streaming support
- [ ] Mobile SDK (iOS/Android)
- [ ] WebAssembly build for browser
- [ ] Federated learning for privacy-preserving group models
- [ ] Integration with major wearable APIs (Apple Health, Google Fit)

## Citation

If you use BERA-PY in research, please cite:

```bibtex
@software{bera_py_2025,
  author = {Sprute, Joseph A. and ERES Institute},
  title = {BERA-PY: Bio-Energetic Resonance Architecture},
  year = {2025},
  url = {https://github.com/eres-institute/bera-py},
  version = {0.1.0}
}

@article{sprute2025acoustic,
  title={Acoustic Biometric Signaling as a Mechanism for Unconscious Physiological Synchronization},
  author={Sprute, Joseph A.},
  journal={Preprint},
  year={2025},
  url={https://ssrn.com/abstract=5608570}
}
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Contact

- **Author**: Joseph A. Sprute
- **Institution**: ERES Institute for New Age Cybernetics
- **Email**: contact@eres.institute
- **Website**: https://eres.institute

## Acknowledgments

- Claude (Anthropic) for collaborative development
- Open-source biometric sensor communities
- PNI research community

---

**Disclaimer**: This software is for research purposes. Not intended for medical diagnosis or treatment. Consult healthcare professionals for medical decisions.
